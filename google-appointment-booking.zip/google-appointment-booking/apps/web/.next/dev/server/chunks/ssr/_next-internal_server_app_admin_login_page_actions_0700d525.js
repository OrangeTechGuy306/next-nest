module.exports = [
"[project]/.next-internal/server/app/admin/login/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_login_page_actions_0700d525.js.map